This folder contains all images embedded in this repository 
